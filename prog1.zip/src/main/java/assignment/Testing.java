package assignment;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

class Main {
    public static void main(String[] args) {
        JIP j = new JIP();
        j.addEffect(new NoRed());

        File file = new File("/Users/vasin/Downloads/prog1/test_images/1.jpg");
        try {
            BufferedImage b = ImageIO.read(file);
            int[][] pixels = ImageEffect.imageToPixels(b);
        } catch (IOException e) {
            System.out.println("Error loading image");
        }
    }
}

