package assignment;

/*
 *
 * CS314H Programming Assignment 1 - Java image processing
 *
 * Included is the Invert effect from the assignment.  Use this as an
 * example when writing the rest of your transformations.  For
 * convenience, you should place all of your transformations in this file.
 *
 * You can compile everything that is needed with
 * javac -d bin src/main/java/assignment/*.java
 *
 * You can run the program with
 * java -cp bin assignment.JIP
 *
 * Please note that the above commands assume that you are in the prog1
 * directory.
 */

import java.util.ArrayList;
import java.util.TreeMap;

class Smooth extends ImageEffect {
    public Smooth() {
        params = new ArrayList<>();
        params.add(new ImageEffectParam(
                "Delta",
                "Defines a k x k neighborhood filter of size k = 2(Delta)+1 for each pixel",
                2, 0, Integer.MAX_VALUE
        ));
    }
    public int[][] apply (int[][] pixels, ArrayList<ImageEffectParam>params) {
        // O(NM)
        int k = params.get(0).getValue(); // defines the (2k+1)x(2k+1) neighborhood size
        // pfx is a prefix array giving the sum of all, for example, red values from (0,0) to (i,j)
        // 3rd dimension is to separate by the 3 different channels
        int[][][] pfx = new int[pixels.length+1][pixels[0].length+1][3];

        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                // using the idea of inclusion-exclusion to get the sum of the rectangle from (0,0) to (i,j)
                pfx[i+1][j+1][0] = getRed(pixels[i][j]) + pfx[i][j+1][0]
                        + pfx[i+1][j][0] - pfx[i][j][0];
                pfx[i+1][j+1][1] = getGreen(pixels[i][j]) + pfx[i][j+1][1]
                        + pfx[i+1][j][1] - pfx[i][j][1];
                pfx[i+1][j+1][2] = getBlue(pixels[i][j]) + pfx[i][j+1][2]
                        + pfx[i+1][j][2] - pfx[i][j][2];
            }
        }

        for (int i = 1; i < pfx.length; i ++) {
            for (int j = 1; j < pfx[0].length; j ++) {
                // upper left endpoint of the neighborhood (accounts for edges)
                int[] p1 = {Math.max(0, i-k-1), Math.max(0, j-k-1)};
                // bottom right endpoint of the neighborhood (accounts for edges)
                int[] p2 = {Math.min(pfx.length-1, i+k), Math.min(pfx[0].length-1, j+k)};
                // computing the sum of values in the neighborhood for each channel
                int red = pfx[p2[0]][p2[1]][0] - pfx[p2[0]][p1[1]][0] - pfx[p1[0]][p2[1]][0] + pfx[p1[0]][p1[1]][0];
                int green = pfx[p2[0]][p2[1]][1] - pfx[p2[0]][p1[1]][1] - pfx[p1[0]][p2[1]][1] + pfx[p1[0]][p1[1]][1];
                int blue = pfx[p2[0]][p2[1]][2] - pfx[p2[0]][p1[1]][2] - pfx[p1[0]][p2[1]][2] + pfx[p1[0]][p1[1]][2];
                // dividing each sum by the size of the rectangle to set pixel value to the average
                pixels[i-1][j-1] = makePixel(
                        (int)(red/((p2[0]-p1[0])*(p2[1]-p1[1]))),
                        (int)(green/((p2[0]-p1[0])*(p2[1]-p1[1]))),
                        (int)(blue/((p2[0]-p1[0])*(p2[1]-p1[1])))
                );
            }
        }

        return pixels;
    }
}

class Sharpen extends ImageEffect {
    public Sharpen() {
        params = new ArrayList<>();
        params.add(new ImageEffectParam(
                        "Delta",
                        "Defines a k x k neighborhood filter of size k = 2(Delta)+1 for each pixel",
                        5, 0, Integer.MAX_VALUE
                )
        );
        params.add(new ImageEffectParam(
                "Sharpness",
                "An integer representing level of sharpness on a 0-100 scale",
                25, Integer.MIN_VALUE, Integer.MAX_VALUE
                )
        );
    }

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        // s:  normalized Sharpness percentage (0-100%) to a value from 0-1
        // passed through an exponential to make small changes in sharpness s less impactful
        int s = (int)(Math.exp(Math.log(101)*params.get(1).getValue()/100.0) - 1);
        int[][] avg = new int[pixels.length][pixels[0].length];// gives mean of pixel values in (2k+1)x(2k+1) neighborhoods
        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                avg[i][j] = pixels[i][j];
            }
        }
        avg = (new Smooth()).apply(avg, params); // Smooth already computes the means for us

        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                int[] mean = {getRed(avg[i][j]), getGreen(avg[i][j]), getBlue(avg[i][j])};
                // original pixel channel values
                int[] a = {getRed(pixels[i][j]), getGreen(pixels[i][j]), getBlue(pixels[i][j])};
                // original mean of the channel values of our pixel
                int m0 = (a[0] + a[1] + a[2])/3;
                // m1 is the new mean after scaling up or down channel values based on
                // whether they were originally greater than or equal to the mean of their
                // neighborhood.
                int m1 = 0;

                // if the original red value is greater or equal to than the mean of the neighborhood,
                // then the new red value is scaled such that its difference
                // from 255 (max value) is decreased by s%.
                // else, the red value is scaled down by s%.
                if (mean[0] < a[0]) { m1 += (int)(a[0] + (255 - a[0])*s/100.0); }
                else if (mean[0] > a[0]) { m1 += (int)(a[0]*(100 - s)/100.0); }
                else { m1 += a[0]; }

                if (mean[1] < a[1]) { m1 += (int)(a[1] + (255 - a[1])*s/100.0); }
                else if (mean[1] > a[1]) { m1 += (int)(a[1]*(100 - s)/100.0); }
                else { m1 += a[1]; }

                if (mean[2] < a[2]) { m1 += (int)(a[2] + (255 - a[2])*s/100.0); }
                else if (mean[2] > a[2]) { m1 += (int)(a[2]*(100 - s)/100.0); }
                else { m1 += a[2]; }
                // getting final average. This is because when sharpening, we want to conserve
                // a pixel's color and change its brightness, meaning we want to multiply
                // all channel values by the same constant scalar.
                m1 /= 3;
                m0 = Math.max(1, m0); // to account for division by zero
                // scaling channel values up or down (capping at 255 to prevent overflow)
                pixels[i][j] = makePixel(Math.min(255, a[0]*m1/m0),
                        Math.min(255, a[1]*m1/m0),
                        Math.min(255, a[2]*m1/m0)
                );
            }
        }
        return pixels;
    }
}

class Highlight extends ImageEffect {
    public Highlight() {
        params = new ArrayList<>();
        params.add(new ImageEffectParam(
                        "Delta",
                        "Defines a k x k neighborhood filter of size k = 2(Delta)+1 for each pixel",
                        2, 0, Integer.MAX_VALUE
                )
        );
        params.add(new ImageEffectParam(
                "Highlight",
                "A number from representing level of edge highlight on a 0-100 scale",
                50, 0,100
        ));
    }
    public int[][] apply (int[][] pixels, ArrayList<ImageEffectParam> params) {
        int[][] max = new int[pixels.length][pixels[0].length]; // gives maximum pixel values in a (2k+1)x(2k+1) neighborhood
        int[][] min = new int[pixels.length][pixels[0].length]; // gives minimum pixel values in a (2k+1)x(2k+1) neighborhood
        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                max[i][j] = pixels[i][j];
                min[i][j] = pixels[i][j];
            }
        }
        max = (new Dilate()).apply(max, params); // Dilate already computes the maximums for us
        min = (new Erode()).apply(min, params); // Erode already computes the minimums for us
        // h:  normalized Highlight percentage (0-100%) to a value from 0-1
        // passed through an exponential to make small changes in highlight less impactful
        double h = (int)(Math.exp(Math.log(101)*params.get(1).getValue()/100.0) - 1)/100.0;
        // threshold represents the minimum difference between maximum and minimum values in
        // a pixel's neighborhood for the pixel to be highlighted
        int threshold = 25;

        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                int[] mx = {getRed(max[i][j]), getGreen(max[i][j]), getBlue(max[i][j])};
                int[] mn = {getRed(min[i][j]), getGreen(min[i][j]), getBlue(min[i][j])};
                // avg0 is original average of the channel values for pixel (i,j)
                double avg0 = (getRed(pixels[i][j]) + getGreen(pixels[i][j]) + getBlue(pixels[i][j]))/3.0;
                // avg1 is the new average after scaling up or down channel values based on
                // whether the difference between mx and mn in the neighborhood is greater or
                // equal to threshold
                double avg1 = 0;

                // if max-min contrast greater than or equal to threshold,
                // then the new red value is scaled such that its difference
                // from 255 (max value) is decreased by 100*h%.
                // else, if max-min contrast less than threshold ,
                // then the new red value is scaled down by 100*h%.
                if (mx[0] - mn[0] < threshold) { avg1 += (1-h)*getRed(pixels[i][j]); }
                else { avg1 += getRed(pixels[i][j]) + h*(255 - getRed(pixels[i][j])); }

                if (mx[1] - mn[1] < threshold) { avg1 += (1-h)*getGreen(pixels[i][j]); }
                else { avg1 += getGreen(pixels[i][j]) + h*(255 - getGreen(pixels[i][j])); }

                if (mx[2] - mn[2] < threshold) { avg1 += (1-h)*getBlue(pixels[i][j]); }
                else { avg1 += getBlue(pixels[i][j]) + h*(255 - getBlue(pixels[i][j])); }
                // getting final average. This is because when highlighting, we want to conserve
                // a pixel's color and change its brightness, meaning we want to multiply
                // all channel values by the same constant scalar.
                avg1 /= 3.0;
                avg0 = Math.max(1, avg0); // to account for division by zero
                // scaling channel values up or down (capping at 255 to prevent overflow)
                pixels[i][j] = makePixel(Math.min(255, (int)(getRed(pixels[i][j])*avg1/avg0)),
                        Math.min(255, (int)(getGreen(pixels[i][j])*avg1/avg0)),
                        Math.min(255, (int)(getBlue(pixels[i][j])*avg1/avg0))
                );
            }
        }
        return pixels;
    }
}

class Erode extends ImageEffect {
    public Erode() {
        params = new ArrayList<>();
        params.add(new ImageEffectParam(
                        "Delta",
                        "Defines a k x k neighborhood filter of size k = 2(Delta)+1 for each pixel",
                        2, 0, Integer.MAX_VALUE
                )
        );
    }
    public int[][] apply (int[][] pixels, ArrayList<ImageEffectParam> params) {
        // time complexity: O(NM + NK + MK) for large K,
        //                  O((NM + NK + MK)log(K)) for small K < 8

        int k = params.get(0).getValue();
        // after pre-computation, pfx[i][j] returns the maximum channel values in the column
        // subsection from max(0, i-k) to min(M, i+k) inclusive
        int[][] pfx = new int[pixels.length][pixels[0].length];

        for (int j = 0; j < pixels[0].length; j ++) {
            // TreeMaps act as counters for number of occurrences of each channel value
            // within +-k vertically of (i,j)
            TreeMap rmap = new TreeMap<Integer, Integer>();
            TreeMap gmap = new TreeMap<Integer, Integer>();
            TreeMap bmap = new TreeMap<Integer, Integer>();
            //Column-wise Pass
            for (int i = 0; i < pixels.length + k; i ++) {
                // Remove old top of the (2k+1)x1 column window only if the top edge is not cropping the window
                if (i > 2*k) {
                    int red = getRed(pixels[i-2*k-1][j]);
                    int green = getGreen(pixels[i-2*k-1][j]);
                    int blue = getBlue(pixels[i-2*k-1][j]);
                    //Decrement red counter
                    rmap.replace(red, (int)rmap.get(red) - 1);
                    if ((int)rmap.get(red) == 0) { rmap.remove(red); }
                    //Decrement green counter
                    gmap.replace(green, (int)gmap.get(green) - 1);
                    if ((int)gmap.get(green) == 0) { gmap.remove(green); }
                    //Decrement blue counter
                    bmap.replace(blue, (int)bmap.get(blue) - 1);
                    if ((int)bmap.get(blue) == 0) { bmap.remove(blue); }
                }
                // Add new bottom of the (2k+1)x1 column window only if the bottom edge is not cropping the window
                if (i < pixels.length) {
                    int red = getRed(pixels[i][j]);
                    int green = getGreen(pixels[i][j]);
                    int blue = getBlue(pixels[i][j]);
                    //Increment red counter
                    if (!rmap.containsKey(red)) { rmap.put(red, 1); }
                    else { rmap.replace(red, (int)rmap.get(red) + 1); }
                    //Increment green counter
                    if (!gmap.containsKey(green)) { gmap.put(green, 1); }
                    else { gmap.replace(green, (int)gmap.get(green) + 1); }
                    //Increment blue counter
                    if (!bmap.containsKey(blue)) { bmap.put(blue, 1); }
                    else { bmap.replace(blue, (int)bmap.get(blue) + 1); }
                }
                // setting the pixel channel values to the minimum in their window
                pfx[Math.max(0, i-k)][j] = makePixel(
                        (int)rmap.firstKey(),
                        (int)gmap.firstKey(),
                        (int)bmap.firstKey()
                );
            }
        }
        //Full Array Pass
        for (int i = 0; i < pixels.length; i ++) {
            TreeMap rmap = new TreeMap<Integer, Integer>();
            TreeMap gmap = new TreeMap<Integer, Integer>();
            TreeMap bmap = new TreeMap<Integer, Integer>();

            for (int j = 0; j < pixels[0].length + k; j ++) {
                // Remove old left column of the (2k+1)x(2k+1) window only if the left edge is not cropping the window
                if (j > 2*k) {
                    int red = getRed(pfx[i][j-2*k-1]);
                    int green = getGreen(pfx[i][j-2*k-1]);
                    int blue = getBlue(pfx[i][j-2*k-1]);
                    //Decrement red counter
                    rmap.replace(red, (int)rmap.get(red) - 1);
                    if ((int)rmap.get(red) == 0) { rmap.remove(red); }
                    //Decrement green counter
                    gmap.replace(green, (int)gmap.get(green) - 1);
                    if ((int)gmap.get(green) == 0) { gmap.remove(green); }
                    //Decrement blue counter
                    bmap.replace(blue, (int)bmap.get(blue) - 1);
                    if ((int)bmap.get(blue) == 0) { bmap.remove(blue); }
                }
                // Add new right column of the (2k+1)x(2k+1) window only if the right edge is not cropping the window
                if (j < pixels[0].length) {
                    int red = getRed(pfx[i][j]);
                    int green = getGreen(pfx[i][j]);
                    int blue = getBlue(pfx[i][j]);
                    //Increment red counter
                    if (!rmap.containsKey(red)) { rmap.put(red, 1); }
                    else { rmap.replace(red, (int)rmap.get(red) + 1); }
                    //Increment green counter
                    if (!gmap.containsKey(green)) { gmap.put(green, 1); }
                    else { gmap.replace(green, (int)gmap.get(green) + 1); }
                    //Increment blue counter
                    if (!bmap.containsKey(blue)) { bmap.put(blue, 1); }
                    else { bmap.replace(blue, (int)bmap.get(blue) + 1); }
                }
                // setting the pixel channel values to the minimum in their window
                pixels[i][Math.max(0, j-k)] = makePixel(
                        (int)rmap.firstKey(),
                        (int)gmap.firstKey(),
                        (int)bmap.firstKey()
                );
            }
        }

        return pixels;
    }
}


class Dilate extends ImageEffect {
    public Dilate() {
        params = new ArrayList<>();
        params.add(new ImageEffectParam(
                        "Delta",
                        "Defines a k x k neighborhood filter of size k = 2(Delta)+1 for each pixel",
                        2, 0, 1000
                )
        );
    }
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {
        // time complexity: O(NM + NK + MK) for large K,
        //                  O((NM + NK + MK)log(K)) for small K < 8

        int k = params.get(0).getValue();
        // after pre-computation, pfx[i][j] returns the maximum channel values in the column
        // subsection from max(0, i-k) to min(M, i+k) inclusive
        int[][] pfx = new int[pixels.length][pixels[0].length];

        for (int j = 0; j < pixels[0].length; j ++) {
            // TreeMaps act as counters for number of occurrences of each channel value
            // within +-k vertically of (i,j)
            TreeMap rmap = new TreeMap<Integer, Integer>();
            TreeMap gmap = new TreeMap<Integer, Integer>();
            TreeMap bmap = new TreeMap<Integer, Integer>();
            //Column-wise Pass
            for (int i = 0; i < pixels.length + k; i ++) {
                // Remove old top of the (2k+1)x1 column window only if the top edge is not cropping the window
                if (i > 2*k) {
                    int red = getRed(pixels[i-2*k-1][j]);
                    int green = getGreen(pixels[i-2*k-1][j]);
                    int blue = getBlue(pixels[i-2*k-1][j]);
                    //Decrement red counter
                    rmap.replace(red, (int)rmap.get(red) - 1);
                    if ((int)rmap.get(red) == 0) { rmap.remove(red); }
                    //Decrement green counter
                    gmap.replace(green, (int)gmap.get(green) - 1);
                    if ((int)gmap.get(green) == 0) { gmap.remove(green); }
                    //Decrement blue counter
                    bmap.replace(blue, (int)bmap.get(blue) - 1);
                    if ((int)bmap.get(blue) == 0) { bmap.remove(blue); }
                }
                // Add new bottom of the (2k+1)x1 column window (if the bottom edge is not cropping the window)
                if (i < pixels.length) {
                    int red = getRed(pixels[i][j]);
                    int green = getGreen(pixels[i][j]);
                    int blue = getBlue(pixels[i][j]);
                    //Increment red counter
                    if (!rmap.containsKey(red)) { rmap.put(red, 1); }
                    else { rmap.replace(red, (int)rmap.get(red) + 1); }
                    //Increment green counter
                    if (!gmap.containsKey(green)) { gmap.put(green, 1); }
                    else { gmap.replace(green, (int)gmap.get(green) + 1); }
                    //Increment blue counter
                    if (!bmap.containsKey(blue)) { bmap.put(blue, 1); }
                    else { bmap.replace(blue, (int)bmap.get(blue) + 1); }
                }
                // setting the pixel channel values to the maximum in their window
                pfx[Math.max(0, i-k)][j] = makePixel(
                        (int)rmap.lastKey(),
                        (int)gmap.lastKey(),
                        (int)bmap.lastKey()
                );
            }
        }
        //Full Array Pass
        for (int i = 0; i < pixels.length; i ++) {
            TreeMap rmap = new TreeMap<Integer, Integer>();
            TreeMap gmap = new TreeMap<Integer, Integer>();
            TreeMap bmap = new TreeMap<Integer, Integer>();

            for (int j = 0; j < pixels[0].length + k; j ++) {
                // Remove old left column of the (2k+1)x(2k+1) window only if the left edge is not cropping the window
                if (j > 2*k) {
                    int red = getRed(pfx[i][j-2*k-1]);
                    int green = getGreen(pfx[i][j-2*k-1]);
                    int blue = getBlue(pfx[i][j-2*k-1]);
                    // Decrement red counter
                    rmap.replace(red, (int)rmap.get(red) - 1);
                    if ((int)rmap.get(red) == 0) { rmap.remove(red); }
                    //Decrement green counter
                    gmap.replace(green, (int)gmap.get(green) - 1);
                    if ((int)gmap.get(green) == 0) { gmap.remove(green); }
                    //Decrement blue counter
                    bmap.replace(blue, (int)bmap.get(blue) - 1);
                    if ((int)bmap.get(blue) == 0) { bmap.remove(blue); }
                }
                // Add new right column of the (2k+1)x(2k+1) window only if the right edge is not cropping the window
                if (j < pixels[0].length) {
                    int red = getRed(pfx[i][j]);
                    int green = getGreen(pfx[i][j]);
                    int blue = getBlue(pfx[i][j]);
                    //Increment red counter
                    if (!rmap.containsKey(red)) { rmap.put(red, 1); }
                    else { rmap.replace(red, (int)rmap.get(red) + 1); }
                    //Increment green counter
                    if (!gmap.containsKey(green)) { gmap.put(green, 1); }
                    else { gmap.replace(green, (int)gmap.get(green) + 1); }
                    //Increment blue counter
                    if (!bmap.containsKey(blue)) { bmap.put(blue, 1); }
                    else { bmap.replace(blue, (int)bmap.get(blue) + 1); }
                }
                // setting the pixel channel values to the maximum in their column window
                pixels[i][Math.max(0, j-k)] = makePixel(
                        (int)rmap.lastKey(),
                        (int)gmap.lastKey(),
                        (int)bmap.lastKey()
                );
            }
        }

        return pixels;
    }
}


//REGULAR METHODS

class NoRed extends ImageEffect {
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {

        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                // sets all channel values to original, but zeroes out the red channel
                pixels[i][j] = makePixel(
                        0,
                        getGreen(pixels[i][j]),
                        getBlue(pixels[i][j])
                );
            }
        }
        return pixels;
    }
}

class NoGreen extends ImageEffect {
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {

        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                // sets all channel values to original, but zeroes out the green channel
                pixels[i][j] = makePixel(
                        getRed(pixels[i][j]),
                        0,
                        getBlue(pixels[i][j])
                );
            }
        }
        return pixels;
    }
}

class NoBlue extends ImageEffect {
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {

        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                // sets all channel values to original, but zeroes out the blue channel
                pixels[i][j] = makePixel(
                        getRed(pixels[i][j]),
                        getGreen(pixels[i][j]),
                        0
                );
            }
        }
        return pixels;
    }
}

class GreenOnly extends ImageEffect {
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {
        // applies the NoRed and NoBlue methods to pixels to yield only green
        return (new NoRed()).apply((new NoBlue()).apply(pixels, params), params);
    }
}

class RedOnly extends ImageEffect {
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {
        // applies the NoGreen and NoBlue methods to pixels to yield only red
        return (new NoGreen()).apply((new NoBlue()).apply(pixels, params), params);
    }
}

class BlueOnly extends ImageEffect {
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {
        // applies the NoGreen and NoRed methods to pixels to yield only blue
        pixels = (new NoGreen()).apply((new NoRed()).apply(pixels, params), params);
        return pixels;
    }
}

class BlackAndWhite extends ImageEffect {

    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {
        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                // getting the average of the three color channels
                int avg = getRed(pixels[i][j]) + getGreen(pixels[i][j]) + getBlue(pixels[i][j]);
                avg /= 3;
                // setting new value to a shade of grey specified by avg
                pixels[i][j] = makePixel(avg, avg, avg);
            }
        }
        return pixels;
    }
}

class VerticalReflect extends ImageEffect {
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {
        for (int j = 0; j < pixels[0].length/2; j ++) {
            for (int i = 0; i < pixels.length; i ++) {
                // swapping values of pixels (i,j) and (i, M-j-1)
                int swap = pixels[i][j];
                pixels[i][j] = pixels[i][pixels[0].length - j - 1];
                pixels[i][pixels[0].length - j - 1] = swap;
            }
        }
        return pixels;
    }
}

class HorizontalReflect extends ImageEffect {
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {
        for (int i = 0; i < pixels.length/2; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                // swapping values of pixels (i,j) and (N-i-1, j)
                int swap = pixels[i][j];
                pixels[i][j] = pixels[pixels.length - i - 1][j];
                pixels[pixels.length - i - 1][j] = swap;
            }
        }
        return pixels;
    }
}

class Grow extends ImageEffect {
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {
        int[][] grown = new int[pixels.length*2][pixels[0].length*2]; // final array

        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j++) {
                int I = 2*i, J = 2*j; // references to the upper left corner of the corresponding 2x2 square for (i,j)
                // setting all values in the 2x2 square to (i,j)'s pixel value
                grown[I][J] = pixels[i][j];
                grown[I+1][J] = pixels[i][j];
                grown[I][J+1] = pixels[i][j];
                grown[I+1][J] = pixels[i][j];
                grown[I+1][J+1] = pixels[i][j];
            }
        }
        return grown;
    }
}

class Shrink extends ImageEffect {
    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {
        int[][] shrunk = new int[(pixels.length+1)/2][(pixels[0].length+1)/2]; // final shrunk array
        int[][] red = new int[(pixels.length+1)/2][(pixels[0].length+1)/2]; // array of final red channel values
        int[][] green = new int[(pixels.length+1)/2][(pixels[0].length+1)/2]; // array of final green channel values
        int[][] blue = new int[(pixels.length+1)/2][(pixels[0].length+1)/2];

        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels[0].length; j ++) {
                // summing channel values in a neighborhood so we can later get average
                red[i/2][j/2] += getRed(pixels[i][j]);
                green[i/2][j/2] += getGreen(pixels[i][j]);
                blue[i/2][j/2] += getBlue(pixels[i][j]);
                // originally, we treat shrunk as a counter for the number of pixels in (i,j)'s neighborhood
                // we use this because at the edges the neighborhood can be smaller than 2x2
                shrunk[i/2][j/2]++;
            }
        }

        for (int i = 0; i < shrunk.length; i ++) {
            for (int j = 0; j < shrunk[0].length; j ++) {
                // computing 2x2 neighborhood average and setting value in final array shrunk
                // originally, shrunk[i][j] gives number of pixel in the neighborhood
                shrunk[i][j] = makePixel(red[i][j]/shrunk[i][j],
                        green[i][j]/shrunk[i][j],
                        blue[i][j]/shrunk[i][j]
                );
            }
        }
        return shrunk;
    }
}

class Threshold extends ImageEffect {

    public Threshold() {
        params = new ArrayList<>();
        params.add(new ImageEffectParam(
                "Threshold",
                "Value above which color channels are rounded up to 255, or otherwise rounded down to 0",
                127, -1, 255
                )
        );
    }

    public int[][] apply (int [][] pixels, ArrayList<ImageEffectParam> params) {
        int threshold = 1 + params.get(0).getValue(); // value above parameter rounded up to 255
        // adding one ensure our end case threshold of 255(+1) makes everything black
        for (int i = 0; i < pixels.length; i ++) {
            for (int j = 0; j < pixels.length; j++) {
                if (threshold == 0) {
                    // accounting for division by zero
                    pixels[i][j] = makePixel(255, 255, 255);
                } else {
                    pixels[i][j] = makePixel(
                            255*Math.min(1, getRed(pixels[i][j])/threshold),
                            255*Math.min(1, getGreen(pixels[i][j])/threshold),
                            255*Math.min(1,getBlue(pixels[i][j])/threshold)
                    );
                    // 255*Math.min(1, val/threshold) does the rounding to 255 or 0
                }
            }
        }
        return pixels;
    }
}

class Invert extends ImageEffect {
    public int[][] apply(int[][] pixels,
                         ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixels[y][x] = ~pixels[y][x];
            }
        }
        return pixels;
    }
}

class Dummy extends ImageEffect {

    public Dummy() {
        params = new ArrayList<>();
        params.add(new ImageEffectParam("ParamName",
                "Description of param.",
                10, 0, 1000));
    }

    public int[][] apply(int[][] pixels,
                         ArrayList<ImageEffectParam> params) {
        // Use params here.
        return pixels;
    }
}
